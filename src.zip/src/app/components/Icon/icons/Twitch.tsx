import { IconProps } from "./IconProps";

export const Twitch = (props: IconProps) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width={props?.width || 24} height={props?.height || 24}>
      <path
        d="M5.7 0L1.4 10.985V55.88h15.284V64h8.597l8.12-8.12h12.418l16.716-16.716V0H5.7zm51.104 36.3L47.25 45.85H31.967l-8.12 8.12v-8.12H10.952V5.73h45.85V36.3zM47.25 16.716v16.716h-5.73V16.716h5.73zm-15.284 0v16.716h-5.73V16.716h5.73z"
        fill={props?.color || "#6441a4"}
        fillRule="evenodd"
      />
    </svg>
  );
};

export default Twitch;
